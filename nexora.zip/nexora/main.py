import sys
import os
import tempfile
import threading
from PyQt5.QtCore import Qt, pyqtSignal, QObject, QTimer
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton, QSpacerItem, QSizePolicy
)
from PyQt5.QtGui import QFont, QColor, QPalette, QBrush, QLinearGradient, QPixmap

import speech_recognition as sr
from faster_whisper import WhisperModel
import google.generativeai as genai

# Configure Gemini API
GOOGLE_API_KEY = 'AIzaSyDQWTFXRd9lNEwQP0Cy2TAL3_IJmyzSF3E'
genai.configure(api_key=GOOGLE_API_KEY)

generation_config = {
    "temperature": 0.7,
    "top_p": 1,
    "top_k": 1,
    "max_output_tokens": 2048,
}

safety_settings = [
    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"}
]

model = genai.GenerativeModel('gemini-1.0-pro-latest',
                              generation_config=generation_config,
                              safety_settings=safety_settings)

convo = model.start_chat()

# Optimized settings for speed
wake_word = 'nexora'

# Use the 'tiny' Whisper model for faster transcription
whisper_size = 'tiny'
num_cores = max(1, os.cpu_count() // 2)
whisper_model = WhisperModel(
    whisper_size,
    device='cpu',
    compute_type='int8',
    cpu_threads=num_cores,
    num_workers=num_cores
)

r = sr.Recognizer()

def wav_to_text(audio_data):
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=True) as temp_audio_file:
        temp_audio_file.write(audio_data.get_wav_data())
        temp_audio_file.flush()
        segments, _ = whisper_model.transcribe(temp_audio_file.name)
        text = ''.join(segment.text for segment in segments)
        return text

def prompt_gpt(audio):
    prompt_text = wav_to_text(audio)
    return prompt_text.strip()

def get_nexora_response(prompt_text):
    if prompt_text:
        convo.send_message(prompt_text)
        output = convo.last.text
        return output
    return "Please provide a valid prompt."

class Communicate(QObject):
    update_status = pyqtSignal(str)
    update_transcription = pyqtSignal(str)
    update_response = pyqtSignal(str)

class VoiceAssistantGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.comm = Communicate()
        self.comm.update_status.connect(self.set_status)
        self.comm.update_transcription.connect(self.set_transcription)
        self.comm.update_response.connect(self.set_response)

    def initUI(self):
        self.setWindowTitle('Nexora Voice Assistant')
        self.setGeometry(100, 100, 600, 500)

        gradient = QLinearGradient(0, 0, 0, 500)
        gradient.setColorAt(0, QColor(10, 50, 70))
        gradient.setColorAt(0.5, QColor(30, 70, 90))
        gradient.setColorAt(1, QColor(50, 100, 120))
        self.setAutoFillBackground(True)
        p = self.palette()
        p.setBrush(QPalette.Window, QBrush(gradient))
        self.setPalette(p)

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignCenter)  # Center-align everything

        # Add the Nexora logo at the top, center-aligned
        self.logo = QLabel(self)
        pixmap = QPixmap('NEXORA.png')
        scaled_pixmap = pixmap.scaled(300, 200, Qt.KeepAspectRatio, Qt.SmoothTransformation)  # Made larger
        self.logo.setPixmap(scaled_pixmap)
        self.logo.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.logo)

        # Add status label
        self.status_label = QLabel('Status: Ready')
        self.status_label.setFont(QFont('Arial', 14, QFont.Bold))
        self.status_label.setStyleSheet("color: white;")
        self.status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_label)

        # Add transcription area
        self.transcription = QTextEdit()
        self.transcription.setReadOnly(True)
        self.transcription.setFont(QFont('Arial', 12, QFont.Bold))
        self.transcription.setStyleSheet("background-color: rgba(46, 46, 46, 0.6); color: white; border-radius: 10px;")
        layout.addWidget(QLabel('Transcription:', alignment=Qt.AlignCenter))
        layout.addWidget(self.transcription)

        # Add response area
        self.response = QTextEdit()
        self.response.setReadOnly(True)
        self.response.setFont(QFont('Arial', 12, QFont.Bold))
        self.response.setStyleSheet("background-color: rgba(46, 46, 46, 0.6); color: white; border-radius: 10px;")
        layout.addWidget(QLabel('Nexora Response:', alignment=Qt.AlignCenter))
        layout.addWidget(self.response)

        # Add activate button
        self.activate_button = QPushButton('Activate Nexora')
        self.activate_button.setFont(QFont('Arial', 14, QFont.Bold))
        self.activate_button.setStyleSheet(
            "background-color: rgba(76, 175, 80, 0.6); color: white; border-radius: 10px; height: 60px;")
        self.activate_button.clicked.connect(self.activate_nexora)
        layout.addWidget(self.activate_button)

        # Add footer
        footer = QLabel('Press the button to activate.')
        footer.setAlignment(Qt.AlignCenter)
        footer.setFont(QFont('Arial', 10))
        footer.setStyleSheet("color: #888888;")
        layout.addWidget(footer)

        # Add some spacing for better layout
        layout.addSpacerItem(QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding))

        # Set layout
        self.setLayout(layout)

    def set_status(self, status):
        self.status_label.setText(f"Status: {status}")

    def set_transcription(self, text):
        self.transcription.setPlainText(text)

    def set_response(self, text):
        self.response.setPlainText(text)

    def activate_nexora(self):
        self.set_status("Listening for prompt...")
        threading.Thread(target=self.listen_for_prompt).start()

    def listen_for_prompt(self):
        try:
            with sr.Microphone() as source:
                r.adjust_for_ambient_noise(source, duration=0.5)
                audio = r.listen(source)

            # Get transcription from audio input
            prompt_text = prompt_gpt(audio)
            self.comm.update_transcription.emit(prompt_text)

            # Get Nexora's response
            response = get_nexora_response(prompt_text)
            self.comm.update_response.emit(response)

        except Exception as e:
            error_message = f"Error: {e}"
            self.comm.update_status.emit(error_message)

class SplashScreen(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Nexora Voice Assistant')
        self.setGeometry(100, 100, 400, 300)  # Set size of the splash screen
        self.setStyleSheet("background-color: black;")

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignCenter)

        # Add logo
        self.logo = QLabel(self)
        pixmap = QPixmap('NEXORA_BLUE.png')  # Logo file name
        scaled_pixmap = pixmap.scaled(400, 400, Qt.KeepAspectRatio, Qt.SmoothTransformation)  # Made larger
        self.logo.setPixmap(scaled_pixmap)
        self.logo.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.logo)

        self.setLayout(layout)

        # Set timer to close splash screen after 3 seconds
        QTimer.singleShot(6000, self.close)  # Close after 3 seconds

def main():
    app = QApplication(sys.argv)

    # Initialize main GUI
    gui = VoiceAssistantGUI()

    # Show the splash screen
    splash = SplashScreen()
    splash.show()

    # Wait for the splash screen to close, then show the main GUI
    QTimer.singleShot(3000, gui.show)  # Show main GUI after splash screen closes

    # Start the application
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()